/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clientserver;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Predicate;

// ===== Utilities =====
final class Util {
    static void sleepMillis(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
    static double msFromNs(long ns) { return ns / 1_000_000.0; }
}

// ===== Naming Interfaces & Implementations =====
interface NamingService<T> {
    void register(String name, T value);
    Optional<T> lookup(String name);
    List<T> query(Predicate<Map.Entry<String, T>> filter);
}

class FlatNamingService<T> implements NamingService<T> {
    private final ConcurrentMap<String, T> registry = new ConcurrentHashMap<>();
    @Override public void register(String name, T value) { registry.put(name, value); }
    @Override public Optional<T> lookup(String name) { return Optional.ofNullable(registry.get(name)); }
    @Override public List<T> query(Predicate<Map.Entry<String, T>> filter) {
        List<T> out = new ArrayList<>();
        for (Map.Entry<String, T> e : registry.entrySet()) if (filter.test(e)) out.add(e.getValue());
        return out;
    }
}

class HierarchicalNamingService<T> implements NamingService<T> {
    private final ConcurrentMap<String, T> registry = new ConcurrentHashMap<>();
    @Override public void register(String path, T value) { registry.put(path, value); }
    @Override public Optional<T> lookup(String path) { return Optional.ofNullable(registry.get(path)); }
    public List<T> listUnder(String prefix) {
        List<T> out = new ArrayList<>();
        String pfx = prefix.endsWith("/") ? prefix : prefix + "/";
        registry.forEach((k, v) -> { if (k.startsWith(pfx)) out.add(v); });
        return out;
    }
    @Override public List<T> query(Predicate<Map.Entry<String, T>> filter) {
        List<T> out = new ArrayList<>();
        for (Map.Entry<String, T> e : registry.entrySet()) if (filter.test(e)) out.add(e.getValue());
        return out;
    }
}

class AttributeBasedNamingService<T> implements NamingService<T> {
    private static class Entry<T> {
        final T value;
        final Map<String, String> attrs;
        Entry(T v, Map<String, String> a) { this.value = v; this.attrs = a; }
    }
    private final ConcurrentMap<String, Entry<T>> registry = new ConcurrentHashMap<>();

    public void register(String name, T value, Map<String, String> attributes) {
        registry.put(name, new Entry<>(value, new HashMap<>(attributes)));
    }
    @Override public void register(String name, T value) { register(name, value, Collections.emptyMap()); }
    @Override public Optional<T> lookup(String name) {
        Entry<T> e = registry.get(name);
        return Optional.ofNullable(e == null ? null : e.value);
    }
    public List<T> queryByAttributes(Map<String, String> required) {
        List<T> out = new ArrayList<>();
        for (Entry<T> e : registry.values()) {
            boolean ok = required.entrySet().stream().allMatch(x -> x.getValue().equals(e.attrs.get(x.getKey())));
            if (ok) out.add(e.value);
        }
        return out;
    }
    @Override public List<T> query(Predicate<Map.Entry<String, T>> filter) {
        List<T> out = new ArrayList<>();
        for (Map.Entry<String, Entry<T>> e : registry.entrySet()) {
            Map.Entry<String, T> mv = new AbstractMap.SimpleEntry<>(e.getKey(), e.getValue().value);
            if (filter.test(mv)) out.add(mv.getValue());
        }
        return out;
    }
}

// ===== Process & Resource Model =====
class Resource {
    enum Type { CPU, MEMORY, DISK, NETWORK }
    private final String id;
    private final Type type;
    private final int capacityUnits;
    public Resource(String id, Type type, int capacityUnits) {
        this.id = id; this.type = type; this.capacityUnits = capacityUnits;
    }
    public String getId() { return id; }
    public Type getType() { return type; }
    public int getCapacityUnits() { return capacityUnits; }
    @Override public String toString() { return type + "(" + id + ":" + capacityUnits + ")"; }
}

class DistributedProcess {
    private final String id;
    private final String host;
    private final List<Resource> resources;
    public DistributedProcess(String id, String host, List<Resource> resources) {
        this.id = id; this.host = host; this.resources = new ArrayList<>(resources);
    }
    public String getId() { return id; }
    public String getHost() { return host; }
    public List<Resource> getResources() { return Collections.unmodifiableList(resources); }
    @Override public String toString() { return "Process{" + id + "@" + host + "}"; }
}

class ResourceManager {
    private final ConcurrentMap<String, DistributedProcess> processes = new ConcurrentHashMap<>();
    public void register(DistributedProcess p) { processes.put(p.getId(), p); }
    public Optional<DistributedProcess> get(String id) { return Optional.ofNullable(processes.get(id)); }
    public List<DistributedProcess> list() { return new ArrayList<>(processes.values()); }
    public List<DistributedProcess> queryByResource(Resource.Type type, int minUnits) {
        List<DistributedProcess> out = new ArrayList<>();
        for (DistributedProcess p : processes.values()) {
            boolean ok = p.getResources().stream()
                .anyMatch(r -> r.getType() == type && r.getCapacityUnits() >= minUnits);
            if (ok) out.add(p);
        }
        return out;
    }
}

// ===== Consistency Models (KV Stores) =====
interface ConsistencyModel {
    void put(String key, String value);
    String get(String key);
    void shutdown();
}

class StrictConsistencyKVStore implements ConsistencyModel {
    private final Map<String, String> store = new HashMap<>();
    private final ReentrantLock lock = new ReentrantLock(true);
    @Override public void put(String key, String value) {
        long start = System.nanoTime();
        lock.lock();
        try {
            Util.sleepMillis(15);
            store.put(key, value);
        } finally { lock.unlock(); }
        System.out.println("Strict put latency: " + Util.msFromNs(System.nanoTime() - start) + " ms");
    }
    @Override public String get(String key) {
        long start = System.nanoTime();
        lock.lock();
        try {
            Util.sleepMillis(5);
            String v = store.get(key);
            System.out.println("Strict get latency: " + Util.msFromNs(System.nanoTime() - start) + " ms");
            return v;
        } finally { lock.unlock(); }
    }
    @Override public void shutdown() {}
}

/*
 * EventualConsistencyKVStore with timestamps and convergence timer.
 * Each node stores Map<String, ValueWithTimestamp>.
 * Gossip merges by choosing the entry with the larger timestamp (last-write-wins).
 */
class EventualConsistencyKVStore implements ConsistencyModel {
    static class ValueWithTimestamp {
        final String value;
        final long timestamp; // epoch millis
        ValueWithTimestamp(String value, long timestamp) {
            this.value = value; this.timestamp = timestamp;
        }
        @Override public String toString() { return value + "@" + timestamp; }
    }

    private final List<ConcurrentMap<String, ValueWithTimestamp>> nodes;
    private final ScheduledExecutorService gossip;
    private final Random random = new Random();
    private final long gossipIntervalMs;

    public EventualConsistencyKVStore(int nodeCount, long gossipIntervalMs) {
        this.gossipIntervalMs = gossipIntervalMs;
        nodes = new ArrayList<>();
        for (int i = 0; i < nodeCount; i++) nodes.add(new ConcurrentHashMap<>());
        gossip = Executors.newSingleThreadScheduledExecutor();
        gossip.scheduleAtFixedRate(this::gossipRound, gossipIntervalMs, gossipIntervalMs, TimeUnit.MILLISECONDS);
    }

    private void gossipRound() {
        int a = random.nextInt(nodes.size());
        int b = random.nextInt(nodes.size());
        if (a == b) return;
        ConcurrentMap<String, ValueWithTimestamp> A = nodes.get(a);
        ConcurrentMap<String, ValueWithTimestamp> B = nodes.get(b);

        for (Map.Entry<String, ValueWithTimestamp> e : A.entrySet()) {
            B.merge(e.getKey(), e.getValue(), (oldVal, newVal) ->
                newVal.timestamp >= oldVal.timestamp ? newVal : oldVal);
        }
        for (Map.Entry<String, ValueWithTimestamp> e : B.entrySet()) {
            A.merge(e.getKey(), e.getValue(), (oldVal, newVal) ->
                newVal.timestamp >= oldVal.timestamp ? newVal : oldVal);
        }
    }

    @Override
    public void put(String key, String value) {
        long start = System.nanoTime();
        int i = random.nextInt(nodes.size());
        long ts = System.currentTimeMillis();
        Util.sleepMillis(5 + random.nextInt(20));
        nodes.get(i).put(key, new ValueWithTimestamp(value, ts));
        System.out.println("Eventual put latency (local write): " + Util.msFromNs(System.nanoTime() - start) + " ms");
    }

    @Override
    public String get(String key) {
        long start = System.nanoTime();
        int i = random.nextInt(nodes.size());
        Util.sleepMillis(5 + random.nextInt(15));
        ValueWithTimestamp v = nodes.get(i).get(key);
        System.out.println("Eventual get latency (random replica): " + Util.msFromNs(System.nanoTime() - start) + " ms");
        return v == null ? null : v.value;
    }

    public ValueWithTimestamp readLatestAcrossAllNodes(String key) {
        ValueWithTimestamp best = null;
        for (ConcurrentMap<String, ValueWithTimestamp> node : nodes) {
            ValueWithTimestamp v = node.get(key);
            if (v == null) continue;
            if (best == null || v.timestamp > best.timestamp) best = v;
        }
        return best;
    }

    public long waitForConvergence(String key, String expectedValue, long timeoutMillis, long pollIntervalMillis) {
        long start = System.currentTimeMillis();
        long deadline = start + timeoutMillis;
        while (System.currentTimeMillis() < deadline) {
            boolean allMatch = true;
            for (ConcurrentMap<String, ValueWithTimestamp> node : nodes) {
                ValueWithTimestamp v = node.get(key);
                if (v == null || !Objects.equals(v.value, expectedValue)) {
                    allMatch = false;
                    break;
                }
            }
            if (allMatch) {
                long elapsed = System.currentTimeMillis() - start;
                System.out.println("Convergence observed in " + elapsed + " ms (gossip interval " + gossipIntervalMs + " ms)");
                return elapsed;
            }
            Util.sleepMillis(pollIntervalMillis);
        }
        System.out.println("Convergence not reached within " + timeoutMillis + " ms.");
        return -1;
    }

    @Override
    public void shutdown() { gossip.shutdownNow(); }
}

// ===== Client–Server Simulation =====
class Request {
    final String clientId;
    final String payload;
    Request(String clientId, String payload) {
        this.clientId = clientId;
        this.payload = payload;
    }
}

class Response {
    final String clientId;
    final String result;
    Response(String clientId, String result) {
        this.clientId = clientId;
        this.result = result;
    }
}

class Server implements Runnable {
    private final BlockingQueue<Request> requestQueue = new LinkedBlockingQueue<>();
    private final ConcurrentMap<String, BlockingQueue<Response>> clientResponseQueues = new ConcurrentHashMap<>();
    private final AtomicBoolean running = new AtomicBoolean(true);

    public void registerClient(String clientId, BlockingQueue<Response> responseQueue) {
        clientResponseQueues.put(clientId, responseQueue);
    }
    public void submitRequest(Request req) { requestQueue.add(req); }
    public void stop() { running.set(false); }

    @Override
    public void run() {
        System.out.println("Server started...");
        System.out.println("");
        while (running.get() || !requestQueue.isEmpty()) {
            try {
                Request req = requestQueue.poll(200, TimeUnit.MILLISECONDS);
                if (req == null) continue;

                long queueStart = System.nanoTime();
                // Simulate processing time
                Util.sleepMillis(150);
                String result = "Processed(" + req.payload + ")";
                long procElapsed = System.nanoTime() - queueStart;

                BlockingQueue<Response> q = clientResponseQueues.get(req.clientId);
                if (q != null) q.put(new Response(req.clientId, result));

                System.out.println("Server handled request from " + req.clientId +
                        " | processing latency: " + Util.msFromNs(procElapsed) + " ms");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        System.out.println("Server stopped.");
    }
}

class Client implements Runnable {
    private final String id;
    private final Server server;
    private final BlockingQueue<Response> responseQueue = new LinkedBlockingQueue<>();

    public Client(String id, Server server) {
        this.id = id;
        this.server = server;
        server.registerClient(id, responseQueue);
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 3; i++) {
                String payload = "Req-" + i + " from " + id;
                long start = System.nanoTime();
                server.submitRequest(new Request(id, payload));
                System.out.println(id + " sent: " + payload);
                Response resp = responseQueue.take();
                long elapsed = System.nanoTime() - start;
                System.out.println(id + " turnaround time: " + Util.msFromNs(elapsed) + " ms | response: " + resp.result);
                Util.sleepMillis(200);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

// ===== Demo Application (Main) =====
public class ClientServer {
    public static void main(String[] args) throws InterruptedException {
        Scanner scanner = new Scanner(System.in);

        // 1) Build processes and resources
        ResourceManager rm = new ResourceManager();
        DistributedProcess serverProc = new DistributedProcess("server", "10.0.0.10",
                List.of(new Resource("cpuS", Resource.Type.CPU, 8),
                        new Resource("netS", Resource.Type.NETWORK, 10)));
        DistributedProcess c1Proc = new DistributedProcess("client1", "10.0.0.1",
                List.of(new Resource("cpu1", Resource.Type.CPU, 2)));
        DistributedProcess c2Proc = new DistributedProcess("client2", "10.0.0.2",
                List.of(new Resource("cpu2", Resource.Type.CPU, 2)));
        DistributedProcess c3Proc = new DistributedProcess("client3", "10.0.0.3",
                List.of(new Resource("cpu3", Resource.Type.CPU, 2)));

        rm.register(serverProc);
        rm.register(c1Proc);
        rm.register(c2Proc);
        rm.register(c3Proc);

        System.out.println("Registered processes: " + rm.list());
        System.out.println("Processes with >= 8 CPU units: " + rm.queryByResource(Resource.Type.CPU, 8));

        // 2) Choose naming service
        System.out.println("\nChoose naming service: 1=Flat, 2=Sequential (hierarchical), 3=Attribute-based");
        int namingChoice = 0;
        while (namingChoice < 1 || namingChoice > 3) {
            System.out.print("Enter 1, 2, or 3: ");
            if (scanner.hasNextInt()) {
                namingChoice = scanner.nextInt();
                if (namingChoice < 1 || namingChoice > 3) System.out.println("Invalid input, try again.");
            } else {
                scanner.next();
                System.out.println("Invalid input, try again.");
            }
        }
        System.out.println("======================");
        NamingService<DistributedProcess> namingService = null;
        AttributeBasedNamingService<DistributedProcess> attrService = null;
        HierarchicalNamingService<DistributedProcess> hierService = null;
        FlatNamingService<DistributedProcess> flatService = null;

        System.out.println("\nNaming demo:");
        switch (namingChoice) {
            case 1:
                flatService = new FlatNamingService<>();
                flatService.register("server", serverProc);
                flatService.register("client1", c1Proc);
                flatService.register("client2", c2Proc);
                flatService.register("client3", c3Proc);
                namingService = flatService;

                long startNs = System.nanoTime();
                DistributedProcess p = namingService.lookup("server").orElse(null);
                long elapsedNs = System.nanoTime() - startNs;
                System.out.println("Using FlatNamingService. Lookup 'server' -> " + p +
                        " | latency: " + Util.msFromNs(elapsedNs) + " ms");
                break;

            case 2:
                hierService = new HierarchicalNamingService<>();
                hierService.register("clusterA/apac/server", serverProc);
                hierService.register("clusterA/apac/clients/client1", c1Proc);
                hierService.register("clusterA/apac/clients/client2", c2Proc);
                hierService.register("clusterA/apac/clients/client3", c3Proc);
                namingService = hierService;

                long hsStart = System.nanoTime();
                List<DistributedProcess> under = hierService.listUnder("clusterA/apac/clients");
                long hsElapsed = System.nanoTime() - hsStart;
                System.out.println("Using HierarchicalNamingService. List under 'clusterA/apac/clients' -> " + under +
                        " | latency: " + Util.msFromNs(hsElapsed) + " ms");
                break;

            case 3:
                attrService = new AttributeBasedNamingService<>();
                attrService.register("server", serverProc, Map.of("role","server","region","apac"));
                attrService.register("client1", c1Proc, Map.of("role","client","region","apac"));
                attrService.register("client2", c2Proc, Map.of("role","client","region","apac"));
                attrService.register("client3", c3Proc, Map.of("role","client","region","apac"));
                namingService = attrService;

                long abStart = System.nanoTime();
                List<DistributedProcess> clients = attrService.queryByAttributes(Map.of("role","client"));
                long abElapsed = System.nanoTime() - abStart;
                System.out.println("Using AttributeBasedNamingService. Query role=client -> " + clients +
                        " | latency: " + Util.msFromNs(abElapsed) + " ms");
                break;
        }
        // 3) Start server and clients (client-server simulation)
        Server server = new Server();
        Thread serverThread = new Thread(server, "ServerThread");
        serverThread.start();

        Thread t1 = new Thread(new Client("client1", server), "Client1Thread");
        Thread t2 = new Thread(new Client("client2", server), "Client2Thread");
        Thread t3 = new Thread(new Client("client3", server), "Client3Thread");

        long csStart = System.nanoTime();
        t1.start(); t2.start(); t3.start();
        t1.join(); t2.join(); t3.join();
        long csElapsed = System.nanoTime() - csStart;
        System.out.println("All clients total runtime: " + Util.msFromNs(csElapsed) + " ms");

        server.stop();
        serverThread.join();

        // 4) Choose consistency model
        System.out.println("\nChoose consistency model: 1=Strict, 2=Eventual");
        int consistencyChoice = 0;
        while (consistencyChoice < 1 || consistencyChoice > 2) {
            System.out.print("Enter 1 or 2: ");
            if (scanner.hasNextInt()) {
                consistencyChoice = scanner.nextInt();
                if (consistencyChoice < 1 || consistencyChoice > 2) System.out.println("Invalid input, try again.");
            } else {
                scanner.next();
                System.out.println("Invalid input, try again.");
            }
        }
        System.out.println("======================");
        ConsistencyModel consistencyModel;
        EventualConsistencyKVStore eventualStore = null;
        switch (consistencyChoice) {
            case 1:
                consistencyModel = new StrictConsistencyKVStore();
                System.out.println("Using StrictConsistencyKVStore.");
                break;
            default:
                eventualStore = new EventualConsistencyKVStore(3, 100);
                consistencyModel = eventualStore;
                System.out.println("Using EventualConsistencyKVStore (timestamps + gossip).");
                break;
        }

        // Measure write and read latency and convergence
        long wStart = System.nanoTime();
        consistencyModel.put("k1", "v1");
        long wElapsed = System.nanoTime() - wStart;
        System.out.println("1: First write latency: " + Util.msFromNs(wElapsed) + " ms");

        long rStart = System.nanoTime();
        String v1 = consistencyModel.get("k1");
        long rElapsed = System.nanoTime() - rStart;
        System.out.println("Read latency after first write: " + Util.msFromNs(rElapsed) + " ms | value=" + v1);

        Util.sleepMillis(50);
        long w2Start = System.nanoTime();
        consistencyModel.put("k1", "v2");
        long w2Elapsed = System.nanoTime() - w2Start;
        System.out.println("2: Second write latency: " + Util.msFromNs(w2Elapsed) + " ms");

        long r2Start = System.nanoTime();
        String v2 = consistencyModel.get("k1");
        long r2Elapsed = System.nanoTime() - r2Start;        
        System.out.println("Read latency after second write: " + Util.msFromNs(r2Elapsed) + " ms | value=" + v2);

        if (eventualStore != null) {
            long elapsed = eventualStore.waitForConvergence("k1", "v2", 5000, 50);
            if (elapsed >= 0) {
                System.out.println("Convergence time: " + elapsed + " ms");
            } else {
                EventualConsistencyKVStore.ValueWithTimestamp latest = eventualStore.readLatestAcrossAllNodes("k1");
                System.out.println("Latest observed across nodes: " + (latest == null ? "null" : latest.toString()));
            }
        } else {
            System.out.println("==============");
            System.out.println("Strict store: latest value is immediately visible.");
        }

        consistencyModel.shutdown();
        scanner.close();
        System.out.println("\nInteractive demo finished.");
    }
}
